#include "..\\lista_doble_cen\\listaDoble.h"
typedef Lista_dob_enl Cola;
Cola crearVacia();

int frente(const Cola& cola);
void desencolar(Cola& cola);
void encolar(Cola& cola, int elem);
int num_elem(const Cola& cola);
void imprimir_cola(const  Cola&);





